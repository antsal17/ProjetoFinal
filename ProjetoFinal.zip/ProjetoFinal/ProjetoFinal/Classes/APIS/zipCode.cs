﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace ProjetoFinal.Classes.APIS
{
    public class zipCode
    {
        public string arteria;
        public string localidade;
        public string troco;
    }

    
}