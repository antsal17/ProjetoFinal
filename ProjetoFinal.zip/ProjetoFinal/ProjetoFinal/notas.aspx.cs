﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace ProjetoFinal
{
    public partial class notas : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //02-09-2020 - António
            //    Registo de utilizador
            //1ª Falta obrigar o preenchimento do aceitar condições em singUp.aspx
            //2ª Falta cerificar campos nif e telefone regex em singUpCont.aspx
            //03-09-2020
            //    Login
            //1º Falta adicionar um campo para fazer "Forgot pass"
            //    Mensagem de email
            //1º Personalizar Mensagens com Texto alusivo ao que se pretende
            //    NewPassRecovery
            //1º Verificar se o template é adequado
            //2º Fazer a verificação de que uma pass tem que ser igual a outra
        }
    }
}